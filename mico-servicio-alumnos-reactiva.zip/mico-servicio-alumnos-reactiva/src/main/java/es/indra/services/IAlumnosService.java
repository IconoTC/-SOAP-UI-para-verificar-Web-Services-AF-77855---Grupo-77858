package es.indra.services;

import es.indra.models.Alumno;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface IAlumnosService {
	
	Flux<Alumno> consultarTodos();
	
	Mono<Alumno> buscarAlumno(Integer id);
	
	Mono<Alumno> crearNuevo(Alumno alumno);
	
	Mono<Void> eliminarAlumno(Integer id);
	
	Mono<Alumno> modificarAlumno(Alumno alumno);

}
