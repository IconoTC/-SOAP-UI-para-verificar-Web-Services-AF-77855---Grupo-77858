package es.indra.persistence;

import org.springframework.data.r2dbc.repository.R2dbcRepository;

import es.indra.models.Alumno;
import reactor.core.publisher.Mono;

// Cualquier Repository de Spring es un bean (componente manejado de Spring)
// no necesita anotacion y se puede inyectar sin problemas
//No necesita anotacion al ser un Repository de Spring
public interface AlumnosDAO extends R2dbcRepository<Alumno, Integer>{
	
	// Ademas de los metodos heredados de Repository podemos crear
	// metodos personalizados utilizando keywords
	// https://docs.spring.io/spring-data/mongodb/reference/repositories/query-keywords-reference.html
	
	public Mono<Alumno> findByNombre(String nombre);
	
}
