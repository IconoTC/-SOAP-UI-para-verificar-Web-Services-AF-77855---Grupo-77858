package es.indra.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

import es.indra.business.IProductosBS;
import es.indra.models.Producto;

import java.util.List;

@RestController
public class ProductosREST {
	
	@Autowired
	private IProductosBS bs;
	
	// http://localhost:8001/listar
	@GetMapping("/listar")
	public List<Producto> listar(){
		return bs.consultarTodos();
	}
	
	// http://localhost:8001/buscar/2
	@GetMapping("/buscar/{id}")
	public Producto buscar(@PathVariable(name = "id") Long id) {
		return bs.buscarProducto(id);
	}
	
	// http://localhost:8001/agregar/descripcion/Prueba/precio/1234
	@PostMapping("/agregar/descripcion/{descripcion}/precio/{precio}")
	public Producto agregar(@PathVariable Long id, @PathVariable String descripcion, @PathVariable double precio) {
		Producto p = new Producto(descripcion, precio);
		return bs.nuevoProducto(p);
	}

	// http://localhost:8001/eliminar/2
	@DeleteMapping("/eliminar/{id}")
	public void borrar(@PathVariable(name = "id") Long id) {
		bs.eliminarProducto(id);
	}

	// http://localhost:8001/buscar/2
	@PutMapping("/modificar/id/{id}/descripcion/{descripcion}/precio/{precio}")
	public Producto modificar(@PathVariable Long id, @PathVariable String descripcion, @PathVariable double precio) {
		Producto p = new Producto(descripcion, precio);
		p.setID(id);
		return bs.modificarProducto(p);
	}

}
