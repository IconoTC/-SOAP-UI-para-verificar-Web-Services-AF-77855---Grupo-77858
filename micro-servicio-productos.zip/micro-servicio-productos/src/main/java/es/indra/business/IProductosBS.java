package es.indra.business;

import java.util.List;

import es.indra.models.Producto;

public interface IProductosBS {
	
	List<Producto> consultarTodos();
	
	Producto buscarProducto(Long id);
	
	Producto nuevoProducto(Producto nuevo);
	
	void eliminarProducto(Long id);
	
	Producto modificarProducto(Producto prod);

}
