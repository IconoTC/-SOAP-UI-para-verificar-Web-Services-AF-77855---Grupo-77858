package es.indra

def lista = ["Juan", "Maria", "Pedro", "Luis"]
for(nombre in lista)
	print(nombre + " ")
println("------ FIN ------")

def cadena1 = "Cadena de texto"
for (letra in cadena1)
	print(letra << " ")
println("------ FIN ------")

// Con el bucle while los numeros del 10 al 1
def num = 11
while (--num > 0)
	print(num + " ")
println("------ FIN ------")

(1..10).each { print(it + " ") }
println("------ FIN ------")

(10..1).each { print(it + " ") }
println("------ FIN ------")


for(i in 1..10)
	print(i + " ")
println("------ FIN ------")

5.times { println("Iteracion: ${it} ") }
println("------ FIN ------")

// En el println no es necesario los parentesis
5.times { println "Iteracion: ${it} " }
println("------ FIN ------")