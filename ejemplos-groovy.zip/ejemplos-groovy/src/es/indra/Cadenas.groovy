package es.indra

// Los String con comillas dobles o simples
def cadena1 = "Cadena de texto"
def cadena2 = 'Cadena de texto'

// GString (interpolation) siempre con comillas dobles
def saldo = 564.32
println("El saldo actual de tu cuenta es ${saldo} euros")

// Heredocs (string en varias lineas) con triple comilla doble o simple
println(''' Hola, que tal?
Como te esta yendo el dia?
aqui pasado por agua ''')

println(""" Hola, que tal?
Como te esta yendo el dia?
aqui pasado por agua """)


// Subcadenas
println(cadena1[0..5])   // los primeros 5 caracteres
println(cadena1[-5..-1]) // los ultimos 5 caracteres


// Concatenacion
println("Saldo: " + saldo + " euros")
println("Saldo: " << saldo << " euros")