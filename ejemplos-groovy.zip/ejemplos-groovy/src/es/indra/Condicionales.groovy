package es.indra

import java.util.Scanner

Scanner sc = new Scanner(System.in)
println("Introduce un numero: ")
def num = sc.nextInt()

if (num % 2 == 0)
	println("El numero ${num} es par")
else
	println("El numero ${num} es impar")
