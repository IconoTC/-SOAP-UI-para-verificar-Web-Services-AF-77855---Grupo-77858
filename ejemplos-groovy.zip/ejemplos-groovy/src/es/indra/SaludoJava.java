package es.indra;

public class SaludoJava {

	public static void main(String[] args) {
		// syso + ctrl + space
		System.out.println("Bienvenidos al curso de SOAPui");
	}

}
