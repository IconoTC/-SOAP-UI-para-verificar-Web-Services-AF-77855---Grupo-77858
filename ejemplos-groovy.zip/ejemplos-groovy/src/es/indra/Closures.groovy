package es.indra

// Forma tradicional es crear el metodo y luego invocarlo
def doble(num) {
	return num * 2
}

println "El doble de 5 es " + doble(5)
	
// Programacion funcional
// Closure: metodo o funcion anonima

def valor = {num -> 
	return num*2
}
println "El doble de 5 es " + valor(5)