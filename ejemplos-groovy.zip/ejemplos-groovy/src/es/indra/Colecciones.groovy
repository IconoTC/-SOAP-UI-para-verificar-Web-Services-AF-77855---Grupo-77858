package es.indra

// List
def lista = ["Juan", "Maria", "Pedro", "Luis"]  //  java.util.ArrayList
lista << "Susana"  // agregar nuevo elemento a la lista
println lista.size()
println lista
println lista.get(0)

// Set
def set = ["Juan", "Maria", "Pedro", "Luis", "Juan", "Maria"] as Set
println set
println set.getClass()  // java.util.LinkedHashSet

// Arrays
def array = ["Juan", "Maria", "Pedro", "Luis"] as Queue
println array.getClass()  // java.util.LinkedList

// Map
def mapa = ["Juan":7.5, "Maria":9.2, "Pedro":3.1, "Luis":8.4]
println mapa
println mapa.get("Pedro")  // 3.1
println mapa.Pedro  // 3.1
println mapa["Pedro"]  // 3.1