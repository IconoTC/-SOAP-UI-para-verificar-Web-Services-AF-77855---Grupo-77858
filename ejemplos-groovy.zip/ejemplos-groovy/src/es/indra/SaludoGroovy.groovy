package es.indra

println("Bienvenidos al curso de SOAPui")


